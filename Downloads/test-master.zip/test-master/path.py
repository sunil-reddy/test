hai how u doing
change mode
