hello can 
how to do
second update


